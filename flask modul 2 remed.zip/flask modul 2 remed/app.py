from flask import Flask, render_template

app=Flask(__name__)

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/analysis', methods=['GET', 'POST'])
def about():
    return render_template("analysis.html")


if __name__ == '__main__':
    app.run(debug=True)